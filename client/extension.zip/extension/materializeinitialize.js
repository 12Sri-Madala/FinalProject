$(document).ready(function(){
    $('select').formSelect();
});